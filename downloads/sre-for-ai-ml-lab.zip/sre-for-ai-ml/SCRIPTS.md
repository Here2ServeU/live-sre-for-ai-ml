# Lab scripts: what each one is and what it does

SRE for AI-ML Systems · T2S · Emmanuel Naweji

Every script is short, plain Python (standard library only) or bash. Open any of them with `less FILE`. Nothing here needs a GPU, Docker or the internet.

| Script | What it is | What it does | Module |
|---|---|---|---|
| `setup/doctor.sh` | The health check | Checks Linux, Python 3, git, curl, and that port 8080 is free | all |
| `modules/*/start.sh` | The reset button | Stops any old server, wipes `~/triage-sre`, copies in a fresh service (model v1, empty logs) | all |
| `server.py` | The model service | Answers `/predict` over HTTP and logs one JSON line per request | 1, 3 |
| `models.py` | Three model versions | v1 good · v2 slow and sometimes crashes · v3 fast, confident, wrong | 1, 3 |
| `load.py` | Pretend users | Sends N requests, 10 at a time; 1 in 5 is a canary with a known answer | 1, 3 |
| `sli.py` | The scorekeeper | Turns the request log into availability, latency and canary accuracy vs `slo.json` | 1, 3 |
| `deploy.py` | The release button | Switches the live model in `config.json` and records it in `deploys.log` | 1, 3 |
| `simulate.py` | A month of traffic | Writes `history.csv`: 43,200 minutes for a quiet, bad-deploy or slow-leak month | 2 |
| `budget.py` | The SRE's calculator | Error budget, % used, burn rates (5m–3d) and the PAGE / TICKET / OK decision | 2 |
| `.lab/incident.sh` | The teammate who ships | Deploys v2 (round 1) or v3 (round 2), sends traffic, prints a page | 3 |
| `RUNBOOK.md` | The 2 a.m. checklist | Confirm → what changed → mitigate → verify → communicate → learn | 3 |
| `POSTMORTEM_TEMPLATE.md` | The blameless write-up | Impact, timeline, root cause, typed and owned action items | 3 |

Settings files: `slo.json` (the three targets), `config.json` (which model is live).
Output files: `logs/requests.jsonl` (one line per request), `deploys.log` (every deploy), `history.csv` (simulated month), `server.pid` (the running server's PID).

---

## setup/doctor.sh — the health check
**Run:** `bash setup/doctor.sh`
Prints one `[ OK ]` or `[WARN]` line per check: Linux, Python 3, git, curl, port 8080. Each WARN tells you the fix on the same line.

## modules/module-N/start.sh — the reset button
**Run:** `bash modules/module-1/start.sh` (same for 2 and 3)
Calls `fresh_copy` in `modules/common.sh`, which:
1. stops the old server if `~/triage-sre/server.pid` exists (`kill`, a polite SIGTERM),
2. deletes `~/triage-sre`,
3. copies a clean `app/` folder there (model v1, no logs),
4. copies `incident.sh` into the hidden `~/triage-sre/.lab/` folder.
Safe to run any time your lab gets into a mess. It never touches the repo itself.

## server.py — the model service
**Run:** `python3 server.py &` (the `&` keeps your prompt) · **Stop:** `kill $(cat server.pid)`
A small multi-threaded web server on `127.0.0.1:8080` (set `PORT=8081` to change it).
- `GET /health` → `{"status": "ok", "model": "v1"}`
- `GET /predict?text=...` (optionally `&label=urgent|normal` for a canary)

For every prediction it: reads `config.json` to see which model is live (so deploys need no restart) → starts a stopwatch → calls that model → records status 200, or 500 if the model crashed → stops the stopwatch → appends one JSON line to `logs/requests.jsonl`:
```json
{"ts": 1792490710.08, "model": "v1", "canary_label": "urgent", "status": 200, "label": "urgent", "confidence": 0.9, "latency_ms": 0.4}
```
That log line is the raw material for every SLI.

## models.py — three versions, three behaviours
Not run directly; `server.py` imports it.
- **v1** (good): labels a ticket urgent if it contains words like *down, failed, payment, security*.
- **v2** (slow and crashy): 30% of requests sleep 0.6 s (a slow dependency); 5% raise an error (HTTP 500). When it answers, it's still right. Breaks **availability and latency**.
- **v3** (wrong): always answers "normal", 97% confident, instantly. Breaks **only quality**.

## load.py — pretend users
**Run:** `python3 load.py --requests 300` (`--port` if you changed it)
Sends N requests, 10 at a time. About 40% are urgent-sounding tickets. Every 5th request is a **canary**: it carries the known right answer so quality can be measured live. Prints `sent 300 requests: 300 ok, 0 failed`.

## sli.py — the scorekeeper
**Run:** `python3 sli.py` (all requests) or `python3 sli.py --last 300` (newest 300 only)
Reads `logs/requests.jsonl` and `slo.json`, then prints:
- latency mean, p50, p95, p99 (nearest-rank percentiles),
- **availability** = requests with status < 500 ÷ all requests (target 99.5%),
- **fast** = requests ≤ 300 ms ÷ all requests (target 95%),
- **canary accuracy** = canaries labelled correctly ÷ canaries (target 90%),
each as PASS/FAIL, then `SLOs MET` or `SLO BREACH`.
Use `--last` after any change, so old traffic doesn't hide new problems.

## deploy.py — the release button
**Run:** `python3 deploy.py v2` · `python3 deploy.py --history`
Writes the new version into `config.json` (the server picks it up on the next request), appends `time  old -> new` to `deploys.log`, and prints the rollback command. `--history` prints every deploy: the first clue in any incident.

## simulate.py — a month of traffic
**Run:** `python3 simulate.py quiet` | `bad-deploy` | `slow-leak`
Writes `history.csv` (`minute,requests,bad`), 43,200 rows = 30 days. Fixed seed, so everyone gets the same numbers.
- every month: ~100 requests/minute following a day/night curve, 0.1% bad, plus 40 one-minute blips at 8% bad,
- **bad-deploy**: the last 40 minutes at 20% bad,
- **slow-leak**: the last 3 days at 1.2% bad.

## budget.py — the SRE's calculator
**Run:** `python3 budget.py` (after `simulate.py`)
- **budget** = (1 − SLO) × all requests in the month; **used %** = bad ÷ budget,
- **burn rate** for the newest 5m, 30m, 1h, 6h and 3d = error rate in that window ÷ allowed error rate (1x = exactly on budget),
- how many times a naive "> 5% bad in any minute" alert would have fired,
- the decision (Google SRE Workbook, multiwindow multi-burn-rate):
  - **PAGE** if 1h and 5m > 14.4x, or 6h and 30m > 6x,
  - **TICKET** if 3d and 6h > 1x,
  - otherwise **OK**.

| Scenario | Used | Decision |
|---|---|---|
| quiet | 22% | OK (naive alert: 34 pages) |
| bad-deploy | 23% | PAGE (1h 25.3x, 5m 30.5x) |
| slow-leak | 43% | TICKET (3d 2.4x) |
| quiet at 99.9% SLO | 109% | TICKET |

## .lab/incident.sh — the teammate who ships
**Run:** `bash .lab/incident.sh 1` (or `2`), with the server running
Round 1 deploys v2, round 2 deploys v3 (output hidden, but recorded in `deploys.log`), sends 300 requests, and prints a pretend page. Your job: follow `RUNBOOK.md`.

## RUNBOOK.md — the 2 a.m. checklist
1. Confirm: `python3 sli.py --last 300` · 2. What changed: `python3 deploy.py --history` · 3. Mitigate: `python3 deploy.py <previous>` · 4. Verify: `python3 load.py --requests 300 && python3 sli.py --last 300` · 5. Communicate · 6. Learn (postmortem).

## POSTMORTEM_TEMPLATE.md — the blameless write-up
Copy it (`cp POSTMORTEM_TEMPLATE.md postmortem-v3.md`) and fill in: summary, impact (`grep -c '"model": "v3"' logs/requests.jsonl` counts requests v3 answered), timeline, root cause, what went well/poorly, where you got lucky, and action items (prevent / detect / mitigate, with owner and due date).

---

**In real life:** `server.py` → your model server · `load.py` → real users or k6/Locust · `sli.py` and `budget.py` → Prometheus/Grafana or cloud monitoring with SLO alert rules · `deploy.py` → CI/CD and model registry · `incident.sh` → a real change going wrong · the PAGER line → PagerDuty/Opsgenie.
