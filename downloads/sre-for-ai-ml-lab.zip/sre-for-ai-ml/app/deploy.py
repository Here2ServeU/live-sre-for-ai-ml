#!/usr/bin/env python3
"""Switch the live model version (the server picks it up on the next request) and record it.
Run: python3 deploy.py v2      python3 deploy.py --history"""
import json, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
LOG = HERE / "deploys.log"
if len(sys.argv) < 2:
    raise SystemExit("usage: deploy.py v1|v2|v3   or   deploy.py --history")
if sys.argv[1] == "--history":
    print(LOG.read_text() if LOG.exists() else "no deploys yet"); raise SystemExit
v = sys.argv[1]
if v not in ("v1", "v2", "v3"):
    raise SystemExit("unknown version")
old = json.loads((HERE / "config.json").read_text())["model_version"]
(HERE / "config.json").write_text(json.dumps({"model_version": v}) + "\n")
with open(LOG, "a") as f:
    f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {old} -> {v}\n")
print(f"deployed {v} (was {old}). Rollback: python3 deploy.py {old}")
