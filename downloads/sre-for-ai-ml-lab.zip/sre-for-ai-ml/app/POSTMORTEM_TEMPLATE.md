# Postmortem: <title>            Status: draft   Date: <yyyy-mm-dd>

> Blameless: we ask what in the system allowed this, not who to blame.

## Summary (2 sentences)
What happened, and what users felt.

## Impact
- SLO(s) breached:
- Duration (detect → mitigate):
- Requests affected / error budget spent:

## Timeline (local time)
| Time | Event |
|---|---|
| | Change deployed |
| | Alert / detection |
| | Mitigation (rollback) |
| | Verified recovery |

## Root cause
The technical cause, and the condition that let it reach users.

## What went well
## What went poorly
## Where we got lucky

## Action items
| Action | Type (prevent / detect / mitigate) | Owner | Due |
|---|---|---|---|
| | | | |
