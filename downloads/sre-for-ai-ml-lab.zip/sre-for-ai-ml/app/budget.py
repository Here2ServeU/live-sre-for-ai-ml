#!/usr/bin/env python3
"""Error budget and burn-rate alerts from history.csv (one row per minute).
Run: python3 budget.py
Alert rules follow the multiwindow, multi-burn-rate pattern from Google's SRE Workbook."""
import csv, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
slo = json.loads((HERE / "slo.json").read_text())["availability"]
rows = [(int(r["requests"]), int(r["bad"])) for r in csv.DictReader(open(HERE / "history.csv"))]
allowed = 1 - slo

total = sum(r for r, _ in rows); bad = sum(b for _, b in rows)
budget = allowed * total
print(f"SLO {slo:.1%} over 30 days · {total:,} requests · budget = {budget:,.0f} bad requests")
print(f"used {bad:,} bad requests = {bad / budget:.0%} of the budget · {max(0, 1 - bad / budget):.0%} left")
print("-" * 62)

def burn(minutes):
    win = rows[-minutes:]
    t = sum(r for r, _ in win); b = sum(x for _, x in win)
    return (b / t) / allowed if t else 0.0

W = {"5m": 5, "30m": 30, "1h": 60, "6h": 360, "3d": 4320}
br = {k: burn(v) for k, v in W.items()}
print("burn rate now (1.0 = spending exactly on budget):  " + "  ".join(f"{k} {v:.1f}x" for k, v in br.items()))

naive = sum(1 for r, b in rows if r and b / r > 0.05)
print(f"a naive 'error rate > 5% in any minute' alert would have fired {naive} times this month")
print("-" * 62)
if br["1h"] > 14.4 and br["5m"] > 14.4:
    print("PAGE    fast burn: 2% of the monthly budget in 1 hour (1h and 5m > 14.4x). Wake someone up.")
elif br["6h"] > 6 and br["30m"] > 6:
    print("PAGE    burn: 5% of the budget in 6 hours (6h and 30m > 6x).")
elif br["3d"] > 1 and br["6h"] > 1:
    print("TICKET  slow burn: on track to blow the budget (3d and 6h > 1x). Fix it this week, no pager.")
else:
    print("OK      no alert. Blips happen; the budget absorbs them.")
