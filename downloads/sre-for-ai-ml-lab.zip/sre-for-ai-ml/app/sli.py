#!/usr/bin/env python3
"""Read logs/requests.jsonl and score the service against slo.json.
Run: python3 sli.py            (all requests)      python3 sli.py --last 300   (most recent 300)"""
import argparse, json, math, statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(); ap.add_argument("--last", type=int, default=0); a = ap.parse_args()
slo = json.loads((HERE / "slo.json").read_text())
rows = [json.loads(l) for l in open(HERE / "logs" / "requests.jsonl") if l.strip()]
if a.last:
    rows = rows[-a.last:]
if not rows:
    raise SystemExit("no requests logged yet - run load.py first")

def pct(vals, p):
    vals = sorted(vals); k = max(0, math.ceil(p / 100 * len(vals)) - 1); return vals[k]   # nearest-rank percentile

lat = [r["latency_ms"] for r in rows]
avail = sum(r["status"] < 500 for r in rows) / len(rows)
fast = sum(r["latency_ms"] <= slo["latency_ms"] for r in rows) / len(rows)
canary = [r for r in rows if r.get("canary_label") and r["status"] == 200]
acc = sum(r["label"] == r["canary_label"] for r in canary) / len(canary) if canary else None
models = sorted({r["model"] for r in rows})

def line(name, value, target, fmt):
    ok = value is not None and value >= target
    v = "n/a" if value is None else fmt(value)
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<22} {v:>8}   target {fmt(target)}")
    return ok

print(f"{slo['service']} · {len(rows)} requests · model(s): {', '.join(models)}")
print(f"  latency  mean {statistics.mean(lat):.0f} ms · p50 {pct(lat,50):.0f} ms · p95 {pct(lat,95):.0f} ms · p99 {pct(lat,99):.0f} ms")
print("-" * 58)
r = [line("availability", avail, slo["availability"], lambda x: f"{x:.2%}"),
     line(f"requests <= {slo['latency_ms']} ms", fast, slo["latency_target"], lambda x: f"{x:.1%}"),
     line("canary accuracy", acc, slo["canary_accuracy"], lambda x: f"{x:.1%}")]
print("-" * 58)
print("SLOs MET" if all(r) else "SLO BREACH - users can feel this")
