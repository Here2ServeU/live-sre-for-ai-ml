#!/usr/bin/env python3
"""Send pretend user traffic. 1 in 5 requests is a labeled 'canary' so we can measure quality.
Run: python3 load.py --requests 300"""
import argparse, random, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

URGENT = ["payment failed", "app is down", "login error", "security breach", "outage today", "data loss", "checkout timeout"]
NORMAL = ["how do I export a report", "feature request", "update my invoice", "change team name", "docs question", "thanks for the help"]

ap = argparse.ArgumentParser(); ap.add_argument("--requests", type=int, default=300); ap.add_argument("--port", type=int, default=8080)
a = ap.parse_args(); rng = random.Random()

def one(i):
    label = "urgent" if rng.random() < 0.4 else "normal"
    text = rng.choice(URGENT if label == "urgent" else NORMAL) + " please help"
    params = {"text": text}
    if i % 5 == 0:
        params["label"] = label                       # canary: we know the right answer
    url = f"http://127.0.0.1:{a.port}/predict?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return 0

with ThreadPoolExecutor(max_workers=10) as ex:
    codes = list(ex.map(one, range(a.requests)))
ok = sum(c == 200 for c in codes)
print(f"sent {a.requests} requests: {ok} ok, {a.requests - ok} failed")
