"""Three versions of the ticket-triage model.
v1: the good one.  v2: slow and sometimes crashes.  v3: fast, healthy... and quietly wrong."""
import random, time

URGENT = {"down", "outage", "crash", "cannot", "login", "failed", "error", "urgent", "broken", "loss", "payment", "security", "breach", "timeout"}

def v1(text):
    hits = len(set(text.lower().split()) & URGENT)
    return ("urgent", min(0.6 + 0.15 * hits, 0.99)) if hits else ("normal", 0.9)

def v2(text):
    if random.random() < 0.30:
        time.sleep(0.6)                      # a slow new dependency
    if random.random() < 0.05:
        raise RuntimeError("tokenizer failed to load")
    return v1(text)

def v3(text):
    return ("normal", 0.97)                  # a bad retrain: confident, fast, and wrong for every urgent ticket

MODELS = {"v1": v1, "v2": v2, "v3": v3}
