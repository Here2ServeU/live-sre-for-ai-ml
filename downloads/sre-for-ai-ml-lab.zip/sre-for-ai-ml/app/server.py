#!/usr/bin/env python3
"""ticket-triage inference service. Logs one JSON line per request to logs/requests.jsonl.
Run: python3 server.py &      Endpoints: /health  /predict?text=...   (add &label=urgent for canary requests)"""
import http.server, json, os, time, urllib.parse
from pathlib import Path
import models

HERE = Path(__file__).resolve().parent
LOG = HERE / "logs" / "requests.jsonl"
PORT = int(os.environ.get("PORT", "8080"))

def version():
    return json.loads((HERE / "config.json").read_text())["model_version"]   # re-read: deploys need no restart

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass
    def reply(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/health":
            return self.reply(200, {"status": "ok", "model": version()})
        if u.path != "/predict":
            return self.reply(404, {"error": "try /predict?text=..."})
        start = time.time(); v = version(); text = q.get("text", [""])[0]
        rec = {"ts": round(start, 3), "model": v, "canary_label": q.get("label", [None])[0]}
        try:
            label, conf = models.MODELS[v](text)
            rec.update(status=200, label=label, confidence=round(conf, 3))
            body = {"label": label, "confidence": round(conf, 3), "model": v}
        except Exception as e:
            rec.update(status=500, error=str(e)); body = {"error": "internal error"}
        rec["latency_ms"] = round((time.time() - start) * 1000, 1)
        LOG.parent.mkdir(exist_ok=True)
        with open(LOG, "a") as f:
            f.write(json.dumps(rec) + "\n")
        self.reply(rec["status"], body)

if __name__ == "__main__":
    (HERE / "server.pid").write_text(str(os.getpid()))
    print(f"ticket-triage serving model {version()} on :{PORT} (logs: logs/requests.jsonl)", flush=True)
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
