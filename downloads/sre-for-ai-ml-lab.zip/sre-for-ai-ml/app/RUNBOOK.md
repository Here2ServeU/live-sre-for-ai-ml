# Runbook: ticket-triage SLO breach

**Stop the bleeding first. Understand it second.**

1. **Confirm the pain** (2 min)
   `python3 sli.py --last 300`  → which SLO is failing: availability, latency or canary accuracy?
2. **What changed?** (2 min)
   `python3 deploy.py --history`  → a deploy in the last hour is the first suspect.
3. **Mitigate** (2 min)
   Roll back to the last good version: `python3 deploy.py <previous>`
4. **Verify** (2 min)
   `python3 load.py --requests 300 && python3 sli.py --last 300`  → SLOs MET?
5. **Communicate**
   One line in the incident channel: impact, what you did, next update time.
6. **Learn**
   Copy POSTMORTEM_TEMPLATE.md and fill it in within 2 working days. Blameless.
