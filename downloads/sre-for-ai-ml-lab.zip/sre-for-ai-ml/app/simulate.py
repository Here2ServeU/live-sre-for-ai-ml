#!/usr/bin/env python3
"""Generate 30 days of per-minute traffic for the ticket-triage service.
Run: python3 simulate.py quiet | bad-deploy | slow-leak      -> history.csv"""
import csv, math, random, sys
from pathlib import Path

scenario = sys.argv[1] if len(sys.argv) > 1 else "quiet"
if scenario not in ("quiet", "bad-deploy", "slow-leak"):
    raise SystemExit("scenario: quiet | bad-deploy | slow-leak")
rng = random.Random(2026)
MIN = 30 * 24 * 60
out = Path(__file__).resolve().parent / "history.csv"
blips = set(rng.sample(range(MIN), 40))              # 40 one-minute hiccups in a month: normal life
with open(out, "w", newline="") as f:
    w = csv.writer(f); w.writerow(["minute", "requests", "bad"])
    for m in range(MIN):
        hour = (m // 60) % 24
        req = int(100 + 60 * math.sin((hour - 6) / 24 * 2 * math.pi)) + rng.randint(0, 10)   # busier by day
        rate = 0.001                                                  # 0.1% bad on a normal minute
        if m in blips:
            rate = 0.08                                               # a blip: 8% bad for one minute
        if scenario == "bad-deploy" and m >= MIN - 40:
            rate = 0.20                                               # last 40 minutes: a bad deploy
        if scenario == "slow-leak" and m >= MIN - 3 * 24 * 60:
            rate = 0.012                                              # last 3 days: quietly 1.2% bad
        bad = sum(rng.random() < rate for _ in range(req))
        w.writerow([m, req, bad])
print(f"wrote 30 days ({MIN:,} minutes) of '{scenario}' traffic to history.csv")
