#!/usr/bin/env bash
# SRE for AI-ML Systems - environment check.  Run: bash setup/doctor.sh
ok()   { printf "  [ OK ]  %s\n" "$1"; }
warn() { printf "  [WARN]  %s\n" "$1"; }
echo "SRE for AI-ML Systems - doctor"; echo "------------------------------"
[ "$(uname -s)" = "Linux" ] && ok "Linux $(uname -r)" || warn "Not Linux. Use Codespaces, WSL or Multipass."
command -v python3 >/dev/null && ok "$(python3 --version)" || warn "python3 missing: sudo apt install -y python3"
command -v git >/dev/null && ok "$(git --version)" || warn "git missing: sudo apt install -y git"
command -v curl >/dev/null && ok "curl found" || warn "curl missing: sudo apt install -y curl"
if (echo > /dev/tcp/127.0.0.1/8080) 2>/dev/null; then warn "Port 8080 is busy. Stop the other program or use PORT=8081."; else ok "Port 8080 is free"; fi
echo "------------------------------"; echo "No GPU or Docker needed for this course."
