#!/usr/bin/env bash
# Module 3 game day: a teammate ships something. Usage: bash .lab/incident.sh 1   (or 2)
set -e
cd "${LAB_DIR:-$HOME/triage-sre}"
case "${1:-1}" in
  1) python3 deploy.py v2 >/dev/null ;;
  2) python3 deploy.py v3 >/dev/null ;;
  *) echo "usage: incident.sh 1|2"; exit 1 ;;
esac
python3 load.py --requests 300 >/dev/null
echo "PAGER: ticket-triage SLO alert fired. You are on call. Open RUNBOOK.md."
