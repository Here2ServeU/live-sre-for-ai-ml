#!/usr/bin/env bash
# Module 3: a fresh copy of the ticket-triage service in ~/triage-sre (model v1, empty logs).
set -e
source "$(dirname "$0")/../common.sh"
fresh_copy
echo "Ready: $LAB"
echo "Next:  cd ~/triage-sre && python3 server.py &"
