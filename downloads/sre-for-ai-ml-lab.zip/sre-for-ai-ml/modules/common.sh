REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAB="${LAB_DIR:-$HOME/triage-sre}"
fresh_copy() {
  if [ -f "$LAB/server.pid" ]; then kill "$(cat "$LAB/server.pid")" 2>/dev/null || true; fi
  rm -rf "$LAB"
  cp -r "$REPO_ROOT/app" "$LAB"
  mkdir -p "$LAB/.lab" && cp "$REPO_ROOT/modules/module-3/incident.sh" "$LAB/.lab/"
}
