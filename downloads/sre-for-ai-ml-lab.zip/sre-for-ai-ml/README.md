# SRE for AI-ML Systems

Transformed 2 Succeed (T2S) · Emmanuel Naweji

Keep a model healthy in production: measure what users feel, alert on what matters, and recover fast.

| Module | Sticky idea | Lab |
|---|---|---|
| 1 · Measure What Users Feel | **If users feel it, measure it.** | SLIs for availability, latency (p95, not the average) and model quality |
| 2 · Spend the Error Budget | **Alert on burn, not on blips.** | Error budget and multiwindow burn-rate alerts on 30 days of traffic |
| 3 · When It Breaks | **Stop the bleeding first.** | Game day: two incidents, rollbacks, a blameless postmortem |

## Setup
Codespaces, WSL Ubuntu or a Multipass VM. Standard-library Python only; no GPU, no Docker.

```bash
git clone https://github.com/Here2ServeU/sre-for-ai-ml
cd sre-for-ai-ml && bash setup/doctor.sh
bash modules/module-1/start.sh && cd ~/triage-sre
python3 server.py &
```

See **SCRIPTS.md** for what every script is and what it does.

Every module's `start.sh` gives you a fresh copy of the service in `~/triage-sre` (model v1, empty logs).
